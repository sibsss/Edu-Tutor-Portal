// Very minimal service worker with offline fallback to /offline
const CACHE_NAME = "edututor-cache-v1";
const OFFLINE_URL = "/offline";

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    try {
      await cache.addAll([OFFLINE_URL]);
    } catch (e) {
      // Ignore if /offline doesn't exist during build; runtime fetch will cache it later.
    }
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// For navigations: try network, fall back to offline page.
self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(request);
        // Optionally, cache the offline page after a successful navigation
        return fresh;
      } catch (e) {
        const cache = await caches.open(CACHE_NAME);
        const cached = await cache.match(OFFLINE_URL);
        return cached || new Response("You are offline.", { status: 200, headers: { "Content-Type": "text/plain" } });
      }
    })());
  }
  // For other requests, let the browser handle by default
});
