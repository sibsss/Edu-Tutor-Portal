How to integrate this PWA patch into your Next.js (App Router) project on Vercel
===============================================================================

Files included:
- public/manifest.webmanifest
- public/sw.js
- public/icons/icon-192.png
- public/icons/icon-512.png

Steps:
1) Copy the contents of 'public/' into your project's /public folder.
   (Create /public if it doesn't exist.)

2) In your app/layout.tsx <head>, add:
   <link rel="manifest" href="/manifest.webmanifest" />
   <meta name="theme-color" content="#0f172a" />

3) You already attempt to register a SW in layout.tsx:
   navigator.serviceWorker.register('/sw.js')
   Ensure that line only runs on the client (it should in a 'use client' component or effect).
   Since you're using App Router, consider moving registration into a small client component and adding it to layout.

4) Make sure you have an /app/offline/page.tsx route. The service worker will fall back to it when offline.
   You do have /app/offline/page.tsx in your project; good.

5) Commit & push to GitHub. Vercel will deploy. Then check:
   - https://<your-domain>/manifest.webmanifest returns 200
   - https://<your-domain>/sw.js returns 200
   - Chrome DevTools > Application > Manifest shows no errors
   - Application > Service Workers shows the SW installed/activated.

Common causes of 404s you had:
- Missing /public/sw.js → navigator.serviceWorker.register('/sw.js') hits 404.
- Missing /public/manifest.webmanifest → <link rel="manifest" ...> hits 404.
- Wrong file extension for manifest (use .webmanifest).
- Files not at site root (must be inside /public to be served from /).

Notes for Next.js 15 'output: export':
- Static export is compatible with this minimal SW; avoid server-only APIs.
- You already set images.unoptimized:true which is required for export.

Optional:
- Add Apple meta tags in <head> for iOS install banner:
  <link rel="apple-touch-icon" href="/icons/icon-192.png" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
